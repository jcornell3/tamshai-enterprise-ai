# Keycloak Setup Guide for Flutter Desktop/Mobile

Complete guide for configuring Keycloak for the Tamshai Flutter application.

## Table of Contents
1. [Server Installation](#server-installation)
2. [Realm Configuration](#realm-configuration)
3. [Client Configuration](#client-configuration)
4. [TOTP Setup](#totp-setup)
5. [User Management](#user-management)
6. [Testing](#testing)

## Server Installation

### Option 1: Docker (Recommended for Development)

```bash
docker run -d \
  --name keycloak \
  -p 8080:8080 \
  -e KEYCLOAK_ADMIN=admin \
  -e KEYCLOAK_ADMIN_PASSWORD=admin \
  quay.io/keycloak/keycloak:latest \
  start-dev
```

Access: http://localhost:8080

### Option 2: Standalone

1. Download from: https://www.keycloak.org/downloads
2. Extract and run:
   ```bash
   cd keycloak-XX.X.X
   bin/kc.bat start-dev  # Windows
   # or
   bin/kc.sh start-dev   # Linux/Mac
   ```

## Realm Configuration

### 1. Create Realm

1. Login to Admin Console
2. Click dropdown next to "Master" realm
3. Click "Create Realm"
4. Settings:
   - **Realm name**: `tamshai`
   - **Enabled**: ON
5. Click "Create"

### 2. Realm Settings

Navigate to Realm Settings:

**General Tab:**
- Display name: `Tamshai Enterprise AI`
- HTML Display name: `<b>Tamshai</b> Enterprise AI`
- Frontend URL: (leave empty for dev)
- Require SSL: `external requests` (for production: `all requests`)

**Login Tab:**
- User registration: ON (if you want self-registration)
- Forgot password: ON
- Remember me: ON
- Verify email: ON (for production)
- Login with email: ON

**Email Tab:** (Configure for production)
- Host: `smtp.gmail.com` (example)
- Port: `587`
- From: `noreply@tamshai.com`
- Enable StartTLS: ON
- Authentication: ON
- Username: your email
- Password: your password

**Tokens Tab:**
- Access Token Lifespan: `5 minutes`
- Access Token Lifespan For Implicit Flow: `15 minutes`
- Client login timeout: `1 minute`
- Login timeout: `30 minutes`
- Login action timeout: `5 minutes`
- Refresh Token Max Reuse: `0`

## Client Configuration

### 1. Create Client

1. Navigate to: Clients → Create client

**General Settings:**
- **Client type**: `OpenID Connect`
- **Client ID**: `tamshai-flutter-client`
- **Name**: `Tamshai Flutter Application`
- **Description**: `Flutter desktop and mobile application`
- Click "Next"

**Capability config:**
- **Client authentication**: OFF (Public client)
- **Authorization**: OFF
- **Authentication flow**:
  - ✅ Standard flow
  - ✅ Direct access grants
  - ☐ Implicit flow (not needed)
  - ☐ Service accounts roles (not needed for public client)
- Click "Next"

**Login settings:**
- **Root URL**: (leave empty)
- **Home URL**: (leave empty)
- **Valid redirect URIs**:
  ```
  http://localhost:*
  http://localhost:*/callback
  http://127.0.0.1:*
  http://127.0.0.1:*/callback
  ```
- **Valid post logout redirect URIs**:
  ```
  http://localhost:*
  http://localhost:*/logout
  http://127.0.0.1:*
  http://127.0.0.1:*/logout
  ```
- **Web origins**: `+` (this allows all redirect URIs)
- Click "Save"

### 2. Advanced Client Settings

Navigate to: Clients → tamshai-flutter-client → Advanced

**Advanced Settings:**
- **Proof Key for Code Exchange Code Challenge Method**: `S256` ⚠️ CRITICAL
- **Access Token Lifespan**: (leave empty to use realm default)
- **OAuth 2.0 Mutual TLS Certificate Bound Access Tokens**: OFF

**Authentication Flow Overrides:**
- Browser Flow: `browser`
- Direct Grant Flow: `direct grant`

Click "Save"

### 3. Client Scopes

Navigate to: Clients → tamshai-flutter-client → Client scopes

**Assigned default client scopes should include:**
- `openid` (required)
- `profile`
- `email`
- `roles`
- `web-origins`
- `offline_access` (for refresh tokens)

If `offline_access` is not assigned:
1. Click "Add client scope"
2. Select "offline_access"
3. Click "Add" → "Default"

## TOTP Setup

### 1. Configure OTP Policy

Navigate to: Authentication → Policies → OTP Policy

**Settings:**
- **OTP Type**: `Time Based`
- **OTP Hash Algorithm**: `SHA1`
- **Number of Digits**: `6`
- **Look Ahead Window**: `1`
- **OTP Token Period**: `30`

Click "Save"

### 2. Configure Authentication Flow

Navigate to: Authentication → Flows

**Option A: Make TOTP Required (Recommended)**

1. Click on "Browser" flow
2. Find "Browser - Conditional OTP" execution
3. Click "⋮" → "Delete"
4. Add new execution:
   - Click "Add step"
   - Select "OTP Form"
   - Click "Add"
5. Set "OTP Form" to "REQUIRED"
6. Click "Save"

**Option B: Make TOTP Conditional**

Keep "Browser - Conditional OTP" and configure:
1. Click on "Condition - User Configured"
2. Set to "REQUIRED"
3. This makes TOTP required only if user has configured it

### 3. Required Actions

Navigate to: Authentication → Required actions

Ensure "Configure OTP" is enabled:
- **Enabled**: ON
- **Default Action**: ON (forces users to set up TOTP on first login)

## User Management

### 1. Create Test User

Navigate to: Users → Add user

**User Details:**
- **Username**: `testuser`
- **Email**: `test@tamshai.com`
- **First name**: `Test`
- **Last name**: `User`
- **Email verified**: ON
- **Enabled**: ON

Click "Create"

### 2. Set Password

1. Go to "Credentials" tab
2. Click "Set password"
3. **Password**: `Test123!` (or your password)
4. **Temporary**: OFF
5. Click "Save"

### 3. Configure TOTP (If Required)

**Option A: User configures on login**
- User will be prompted on first login
- Scan QR code with authenticator app
- Enter OTP code

**Option B: Admin configures**
1. Go to user → Credentials tab
2. Click "Credential Reset"
3. Select "Configure OTP"
4. User will be prompted on next login

### 4. Assign Roles (Optional)

1. Go to user → Role mapping tab
2. Click "Assign role"
3. Select roles to assign
4. Click "Assign"

## Testing

### 1. Test Login Flow

**Manual Browser Test:**

1. Construct authorization URL:
```
http://localhost:8080/realms/tamshai/protocol/openid-connect/auth?
  client_id=tamshai-flutter-client&
  redirect_uri=http://localhost:8888/callback&
  response_type=code&
  scope=openid%20profile%20email%20offline_access
```

2. Open in browser
3. Login with test user
4. Enter TOTP code (if enabled)
5. Should redirect to callback URL with authorization code

### 2. Test Token Exchange

Using curl:

```bash
# Exchange authorization code for tokens
curl -X POST 'http://localhost:8080/realms/tamshai/protocol/openid-connect/token' \
  -H 'Content-Type: application/x-www-form-urlencoded' \
  -d 'grant_type=authorization_code' \
  -d 'client_id=tamshai-flutter-client' \
  -d 'code=YOUR_AUTH_CODE' \
  -d 'redirect_uri=http://localhost:8888/callback'
```

### 3. Test Token Refresh

```bash
curl -X POST 'http://localhost:8080/realms/tamshai/protocol/openid-connect/token' \
  -H 'Content-Type: application/x-www-form-urlencoded' \
  -d 'grant_type=refresh_token' \
  -d 'client_id=tamshai-flutter-client' \
  -d 'refresh_token=YOUR_REFRESH_TOKEN'
```

### 4. Test Flutter App

```bash
cd tamshai_app
flutter run -d windows
```

1. Click "Sign In with Keycloak"
2. Enter credentials
3. Enter TOTP code
4. Should see home screen

## Troubleshooting

### Issue: "Invalid redirect_uri"

**Solution:**
- Verify redirect URIs in client settings
- Include `http://localhost:*` for wildcard port matching
- Include both `localhost` and `127.0.0.1`

### Issue: "PKCE verification failed"

**Solution:**
- Ensure "Proof Key for Code Exchange" is set to `S256` in Advanced settings
- flutter_appauth automatically adds PKCE parameters

### Issue: "Client not found"

**Solution:**
- Verify client ID is exactly `tamshai-flutter-client`
- Check client is enabled
- Verify realm is correct

### Issue: "Invalid_grant: Code not valid"

**Solution:**
- Authorization codes expire quickly (60 seconds)
- Don't reuse authorization codes
- Ensure system clocks are synchronized

### Issue: TOTP not working

**Solution:**
- Verify OTP policy settings
- Check authenticator app time sync
- Increase "Look Ahead Window" to 2 or 3
- Verify "OTP Form" is in browser flow

## Production Checklist

Before deploying to production:

- [ ] Change admin password
- [ ] Configure SSL/TLS certificates
- [ ] Set "Require SSL" to "all requests"
- [ ] Configure email server
- [ ] Enable email verification
- [ ] Configure password policies
- [ ] Enable brute force detection
- [ ] Review session timeouts
- [ ] Configure backup/recovery
- [ ] Set up monitoring
- [ ] Document realm configuration
- [ ] Use environment-specific realms
- [ ] Review and limit client scopes
- [ ] Configure logging
- [ ] Set up database (not H2)

## Additional Resources

- [Keycloak Admin Guide](https://www.keycloak.org/docs/latest/server_admin/)
- [Keycloak Security Guide](https://www.keycloak.org/docs/latest/server_admin/#_security_best_practices)
- [OAuth 2.0 Spec](https://oauth.net/2/)
- [OIDC Spec](https://openid.net/connect/)
- [PKCE RFC](https://tools.ietf.org/html/rfc7636)

## Support

If issues persist:
1. Check Keycloak logs: `data/log/keycloak.log`
2. Enable debug logging in Keycloak
3. Use browser developer tools network tab
4. Check Flutter logs for detailed errors
