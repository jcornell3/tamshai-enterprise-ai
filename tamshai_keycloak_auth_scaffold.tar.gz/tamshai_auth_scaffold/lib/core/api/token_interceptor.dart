import 'package:dio/dio.dart';
import 'package:logger/logger.dart';
import '../storage/secure_storage_service.dart';
import '../auth/providers/auth_provider.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

/// Dio interceptor for automatic token injection and refresh
/// 
/// Features:
/// - Automatically adds Bearer token to requests
/// - Detects 401 responses and triggers token refresh
/// - Retries failed requests after refresh
class AuthTokenInterceptor extends Interceptor {
  final SecureStorageService _storage;
  final Ref _ref;
  final Logger _logger;
  
  bool _isRefreshing = false;
  final List<RequestOptions> _requestsQueue = [];

  AuthTokenInterceptor({
    required SecureStorageService storage,
    required Ref ref,
    Logger? logger,
  })  : _storage = storage,
        _ref = ref,
        _logger = logger ?? Logger();

  @override
  Future<void> onRequest(
    RequestOptions options,
    RequestInterceptorHandler handler,
  ) async {
    try {
      // Check if token is expired
      final isExpired = await _storage.isTokenExpired();
      
      if (isExpired) {
        _logger.i('Token expired, refreshing before request');
        
        // Trigger refresh
        await _ref.read(authNotifierProvider.notifier).refreshToken();
      }

      // Get current access token
      final accessToken = await _storage.getAccessToken();

      if (accessToken != null) {
        // Add authorization header
        options.headers['Authorization'] = 'Bearer $accessToken';
        _logger.d('Added auth token to request: ${options.path}');
      } else {
        _logger.w('No access token available for request: ${options.path}');
      }

      handler.next(options);
    } catch (e, stackTrace) {
      _logger.e('Error in request interceptor', error: e, stackTrace: stackTrace);
      handler.next(options);
    }
  }

  @override
  Future<void> onError(
    DioException err,
    ErrorInterceptorHandler handler,
  ) async {
    if (err.response?.statusCode == 401) {
      _logger.w('Received 401 response, attempting token refresh');

      try {
        if (_isRefreshing) {
          // Already refreshing, queue this request
          _logger.d('Token refresh in progress, queueing request');
          _requestsQueue.add(err.requestOptions);
          return;
        }

        _isRefreshing = true;

        // Attempt to refresh token
        await _ref.read(authNotifierProvider.notifier).refreshToken();

        _logger.i('Token refreshed successfully, retrying request');

        // Get new token
        final newToken = await _storage.getAccessToken();
        
        if (newToken == null) {
          _logger.e('No token after refresh');
          handler.next(err);
          return;
        }

        // Retry the original request with new token
        final requestOptions = err.requestOptions;
        requestOptions.headers['Authorization'] = 'Bearer $newToken';

        final dio = Dio();
        final response = await dio.fetch(requestOptions);

        // Process queued requests
        await _processQueue(newToken);

        handler.resolve(response);
      } catch (e, stackTrace) {
        _logger.e('Token refresh failed', error: e, stackTrace: stackTrace);
        
        // Clear queue on refresh failure
        _requestsQueue.clear();
        
        // User will be logged out by auth provider
        handler.next(err);
      } finally {
        _isRefreshing = false;
      }
    } else {
      handler.next(err);
    }
  }

  /// Process queued requests with new token
  Future<void> _processQueue(String newToken) async {
    _logger.i('Processing ${_requestsQueue.length} queued requests');

    final dio = Dio();
    
    for (final options in _requestsQueue) {
      try {
        options.headers['Authorization'] = 'Bearer $newToken';
        await dio.fetch(options);
      } catch (e) {
        _logger.e('Failed to process queued request', error: e);
      }
    }

    _requestsQueue.clear();
  }
}

/// Dio client provider with auth interceptor
final dioProvider = Provider<Dio>((ref) {
  final dio = Dio(
    BaseOptions(
      // TODO: Set your API base URL
      baseUrl: 'https://api.tamshai.com',
      connectTimeout: const Duration(seconds: 30),
      receiveTimeout: const Duration(seconds: 30),
      headers: {
        'Content-Type': 'application/json',
      },
    ),
  );

  // Add auth interceptor
  dio.interceptors.add(
    AuthTokenInterceptor(
      storage: ref.watch(secureStorageProvider),
      ref: ref,
      logger: ref.watch(loggerProvider),
    ),
  );

  // Add logging interceptor (development only)
  dio.interceptors.add(
    LogInterceptor(
      requestBody: true,
      responseBody: true,
      error: true,
      logPrint: (obj) => ref.read(loggerProvider).d(obj),
    ),
  );

  return dio;
});
